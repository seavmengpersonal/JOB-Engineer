/*
 * Translate default messages for the jQuery UI Datepicker plugin.
 */
jQuery.extend(true, jQuery.datepicker.regional[""], datepickerL10n);
jQuery(function() {
	jQuery.datepicker.setDefaults( jQuery.datepicker.regional[""] );
});
